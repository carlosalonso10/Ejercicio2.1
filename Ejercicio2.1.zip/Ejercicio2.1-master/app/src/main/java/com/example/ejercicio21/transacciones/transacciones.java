package com.example.ejercicio21.transacciones;

public class transacciones {
    /*Creacion de la tabla*/
    public static final String tablavideo = "video";
    public static final String video = "video";
    public static final String CreateTableVideo = "CREATE TABLE video(video BLOB)";
    public static final String DropTableVideo = "DROP TABLE IF EXISTS video";

    /* Creacion del nombre de la base de datos */
    public static final String NameDataBase = "DBActual";
}
